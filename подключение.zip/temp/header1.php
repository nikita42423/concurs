<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
   <link rel="stylesheet" href="css/bootstrap.css">
   <script src="js/bootstrap.js"></script>
   <script src="js/jquery-3.6.3.min.js"></script>

</head>
<body>
    <header style="background-color: cadetblue;">
    <div class="container">
        <div class="row">
            <div class="col-lg-2" style="padding-top: 1%; padding-bottom: 1%;">
                <img src="img/logo.png" alt="" height="80" width="80">
            </div>
            <div class="col-lg-10">
                <h1 style="text-align: center; text-shadow: 1px 1px white; color: blue; padding-top: 2%;">Открытый конкурс Интернет - проектов </h1>
            </div>
        </div>
    </div>
    </header>
    <header style="background-color: gray;">
    <div class="container">
        <div class="row">
            <div class="col-lg-8" style="padding-top: 1%; padding-bottom: 1%;">
               <a href="#"><button type="button" class="btn btn-info">Рейтинг</button></a> 
            </div>
            <div class="col-lg-4" style="padding-top: 1%; padding-bottom: 1%;">
                <a href="#"><button type="button" class="btn btn-info">Регистрация</button></a>&nbsp;
                <a href="#"><button type="button" class="btn btn-info">Вход</button></a> 
             </div>
           
        </div>

    </div>
</header>
</body>