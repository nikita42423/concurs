<footer style="background-color:  cadetblue;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p style="text-align: center; color: blue; text-shadow: 1px 1px white; padding-top: 1%;">&copy; Copyright | INTEL - DEAF 2023г</p>
            </div>
        </div>
    </div>
</footer>

</body>
</html>